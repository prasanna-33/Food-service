const sql = require("./db.js");

// constructor
const Driver = function(driver) {
    this.name = driver.name;
    this.email = driver.email;
    this.contact = driver.contact;
    this.username = driver.username;
    this.password = driver.password;
  };

  Driver.create = (newDriver, result) => {
    sql.query("INSERT INTO driver SET ?", newDriver, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
  
      console.log("created driver: ", { id: res.insertId, ...newDriver });
      result(null, { id: res.insertId, ...newDriver });
    });
  };

  Driver.getAll = (name, result) => {
    let query = "SELECT * FROM driver";
  
    if (name) {
      query += ` WHERE name LIKE '%${name}%'`;
    }
  
    sql.query(query, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
  
      console.log("driver: ", res);
      result(null, res);
    });
  };

  Driver.findById = (id, result) => {
    sql.query(`SELECT * FROM driver WHERE id = "${id}" OR name like "%${id}%" OR email like "%${id}%" OR username ="${id}"`, 
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
  
      if (res.length) {
        console.log("found driver: ", res[0]);
        result(null, res[0]);
        return;
      }
  
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
    });
  };

  Driver.updateById =(id, driver, result) => {
    sql.query(
      "UPDATE driver SET name = ? , email = ?, contact = ?, username = ?, password = ? WHERE id = ?",
      [driver.name,driver.email,driver.contact,driver.username, driver.password, id],
      (err, res) =>{
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
  
        if (res.affectedRows == 0) {
          // not found driver with the id
          result({ kind: "not_found" }, null);
          return;
        }
  
        console.log("updated tutorial: ", { id: id, ...driver });
        result(null, { id: id, ...driver });
      }
    );
  };

  Driver.remove=(id, result) =>{
    sql.query("DELETE FROM driver WHERE id = ? ",id,(err, res) =>{
      if(err){
        console.log("error :", err);
        result(null,err);
        return
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }
  
      console.log("deleted driver with id: ", id);
      result(null, res);
    });
  };
  Driver.removeAll = result => {
    sql.query("DELETE FROM driver", (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
  
      console.log(`deleted ${res.affectedRows} driver`);
      result(null, res);
    });
  };
  module.exports = Driver;