const sql = require("./db.js");

// constructor
const Restaurant = function(restaurant) {
    this.name = restaurant.name;
    this.contact = restaurant.contact;
    this.address = restaurant.address;
    this.city = restaurant.city;
    this.state = restaurant.state;
    this.pincode = restaurant.pincode;
    this.lat = restaurant.lat;
    this.lon = restaurant.lon;
  };

  Restaurant.create = (newRestaurant, result) => {
    sql.query("INSERT INTO restaurant SET ?", newRestaurant, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
  
      console.log("created restaurant: ", { id: res.insertId, ...newRestaurant });
      result(null, { id: res.insertId, ...newRestaurant });
    });
  };

  Restaurant.getAll = (name, result) => {
    let query = "SELECT * FROM restaurant";
  
    if (name) {
      query += ` WHERE name LIKE '%${name}%'`;
    }
    console.log(query);
  
    sql.query(query, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
  
      console.log("restuarant: ", res);
      result(null, res);
    });
  };

  Restaurant.findByMatch = (id, result) => {
    sql.query(`SELECT * FROM restaurant WHERE id like "${id}" OR name like"%${id}%" OR address like"${id}" OR city like "${id}" OR state like "${id}"`, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
  
      if (res.length) {
        console.log("found restaurant: ", res[0]);
        result(null, res[0]);
        return;
      }
  
      // not found Restaurant
      result({ kind: "not_found" }, null);
    });
  };
  Restaurant.updateById = (id, restaurant, result) => {
    sql.query(
      "UPDATE restaurant SET name = ?, contact = ?, address = ?, city = ?,state = ?,pincode = ? ,lat = ?, lon = ? WHERE id = ?",
      [restaurant.name, restaurant.contact, restaurant.address, restaurant.city, restaurant.state, restaurant.pincode, restaurant.lat, restaurant.lon, id],
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
  
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
  
        console.log("updated restaurant: ", { id: id, ...restaurant});
        result(null, { id: id, ...restaurant});
      }
    );
  };

  Restaurant.remove=(id, result) =>{
    sql.query("DELETE FROM restaurant WHERE id = ? ",id,(err, res) =>{
      if(err){
        console.log("error :", err);
        result(null,err);
        return
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("deleted restaurant with id: ", id);
      result(null, res);
    });
  };


  module.exports = Restaurant;