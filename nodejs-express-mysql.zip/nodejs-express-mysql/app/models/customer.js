const sql = require("./db.js");

// constructor
const Customer = function(customer) {
    this.name = customer.name;
    this.email = customer.email;
    this.username = customer.username;
    this.password = customer.password;
    this.lat = customer.lat,
    this.lon = customer.lon,
    this.contact = customer.contact;
  };

  Customer.create = (newCustomer, result) => {
    sql.query("INSERT INTO customer SET ?", newCustomer, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }

  
      console.log("created customer: ", { id: res.insertId, ...newCustomer });
      result(null, {id: res.insertId, ...newCustomer});
    });
  };

  Customer.getAll = (name, result) => {
    let query = "SELECT * FROM customer";
  
    if (name) {
      query += ` WHERE name LIKE '%${name}%'`;
    }
  
    sql.query(query, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }
  
      console.log("customer: ", res);
      result(null, res);
    });
    
  };

  Customer.findByMatch = (id, result) => {
    sql.query(`SELECT * FROM customer WHERE id like "${id}" OR name like"${id}" OR username like"${id}" OR email like "${id}"`, (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(err, null);
        return;
      }
  
      if (res.length) {
        console.log("found customer: ", res);
        result(null, res);
        return;
      }
  
      // not found Tutorial with the id
      result({ kind: "not_found" }, null);
    });
  };
  Customer.updateById = (id, customer, result) => {
    sql.query(
      "UPDATE customer SET name = ?, email = ?, username = ?, password = ?,lat = ?, lon = ?, contact = ? WHERE id = ?",
      [customer.name, customer.email, customer.username, customer.password, customer.lat, customer.lon, customer.contact, id],
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(null, err);
          return;
        }
  
        if (res.affectedRows == 0) {
          result({ kind: "not_found" }, null);
          return;
        }
  
        console.log("updated customer: ", { id: id, ...customer});
        result(null, { id: id, ...customer});
      }
    );
  };
  

  Customer.remove=(id, result) =>{
    sql.query("DELETE FROM customer WHERE id = ? ",id,(err, res) =>{
      if(err){
        console.log("error :", err);
        result(null,err);
        return
      }
      if (res.affectedRows == 0) {
        result({ kind: "not_found" }, null);
        return;
      }

      console.log("deleted customer with id: ", id);
      result(null, res);
    });
  };

  module.exports = Customer;