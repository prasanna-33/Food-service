
const restaurant = require("../controllers/restaurant.controller");
// const { route } = require("./tutorial.routes");

var router = require("express").Router();

//create a new restaurant 
router.post("/", restaurant.create);
//retrieve all restaurant
router.get("/", restaurant.findAll);

// Retrieve a single Tutorial with id
router.get("/:id", restaurant.findOne);
 
router.put("/:id", restaurant.update);
 
router.delete("/:id", restaurant.delete);

module.exports = router;
