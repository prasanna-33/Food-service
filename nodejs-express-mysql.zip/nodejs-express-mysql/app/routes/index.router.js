const tutorial = require('./tutorial.routes');
const restaurant = require('./restaurant.routes');
const customer = require('./customer.router');
 const driver = require('./driver.router');


const app = require('express')('app')

    app.use('/tutorial', tutorial);
    app.use('/restaurant', restaurant);
    app.use('/customer',customer);
     app.use('/driver',driver);

module.exports = app