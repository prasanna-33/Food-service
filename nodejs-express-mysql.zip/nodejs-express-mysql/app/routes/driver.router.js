
const driver = require("../controllers/driver.controller");
const { route } = require("./tutorial.routes");

var router = require("express").Router();

//create a new driver 
router.post("/", driver.create);
//retrieve all driver
router.get("/", driver.findAll);

// Retrieve a single driver with id
router.get("/:id", driver.findOne);

router.put("/:id",driver.update);

router.delete("/:id",driver.delete);

module.exports = router;
