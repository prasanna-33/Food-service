const customer = require("../controllers/customer.controller");
// const { route } = require("./tutorial.routes");

var router = require("express").Router();

//create a new restaurant 
router.post("/", customer.create);
//retrieve all restaurant
router.get("/", customer.findAll);

// Retrieve a single Tutorial with id
router.get("/:id", customer.findOne);

router.put("/:id",customer.update);

router.delete("/:id",customer.delete);

module.exports = router;