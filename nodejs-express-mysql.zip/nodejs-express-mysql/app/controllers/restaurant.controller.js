const Restaurant = require("../models/restaurant.js");

function check({ restaurant }) {
  try {
    const error = {};
    let length = restaurant.name ? restaurant.name.length : 0;

    if (length === 0) {
      error.code = 400;
      error.message ="Name is Required";
      return error;
    }

    return error;
  } catch (e) {
    throw new Error(e.message);
  }
};

// Create and Save a new Restaurant
exports.create = (req, res) => {
    if (!req.body) {
        res.status(400).send({
          message: "Content can not be empty!"
        });
      }
      const error = check({ restaurant:req.body });
      if(error.code==400){
        res.send([error.message]);
      }
    
      // Create a Restaurant
      const restaurant = new Restaurant({
        name: req.body.name,
        contact: req.body.contact,
        address: req.body.address,
        city : req.body.city,
        state : req.body.state,
        pincode : req.body.pincode,
        lat : req.body.lat,
        lon : req.body.lon
      });

      // Save Tutorial in the database
      Restaurant.create(restaurant, (err, data) => {
        if (err)
          res.status(500).send({
            message:
              err.message || "Some error occurred while creating the Tutorial."
          });
        else res.send(data);
      });
    };

// Retrieve all Restaurant from the database (with condition).    
exports.findAll = (req, res) => {
    const name = req.query.name;
    
    Restaurant.getAll(name, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving restaurant."
        });
      else res.send(data);
    });
  };
  //Retrieve one Restaurant by id
  exports.findOne = (req, res) => {
    Restaurant.findByMatch(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Tutorial with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving Tutorial with id " + req.params.id
          });
        }
      } else res.send(data);
    });
  };
  exports.update =(req, res) =>{
    if(!req.body){
      res.status(400).send({
        message:"Content can not be empty "
      });
    }
    console.log(req.body)

    Restaurant.updateById(req.params.id,new Restaurant(req.body),(err,data)=>{
      if(err){
        if(err.kind==="not_found"){
          res.status(400).send({
            message:`Not found Restaurant with id ${req.parms.id}.`
          });
        }else {
          res.status(500).send({
            message :"Error updating the Driver with id " + req.params.id
          });
        }
      }
    }
  );
  }
  exports.delete = (req, res) => {
    Restaurant.remove(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found restaurant with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Could not delete restaurant with id " + req.params.id
          });
        }
      } else res.send({ message: `Driver was deleted successfully!` });
    });
  };