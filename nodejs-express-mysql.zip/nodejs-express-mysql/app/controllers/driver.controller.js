const Driver = require("../models/driver.js");

// Create and Save a new Tutorial
exports.create = (req, res) => {
    if (!req.body) {
        res.status(400).send({
          message: "Content can not be empty!"
        });
      }
    
      // Create a Tutorial
      const driver = new Driver({
        name: req.body.name,
        email: req.body.email,
        contact: req.body.contact,
        username : req.body.username,
        password : req.body.password,
      });

      // Save Tutorial in the database
      Driver.create(driver, (err, data) => {
        if (err)
          res.status(500).send({
            message:
              err.message || "Some error occurred while creating the Tutorial."
          });
        else res.send(data);
      });
    };

// Retrieve all Driver from the database (with condition).    
exports.findAll = (req, res) => {
    const name = req.query.name;
    
    Driver.getAll(name, (err, data) => {
      if (err)
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving driver."
        });
      else res.send(data);
    });
  };
  //Retrieve one Driver by id
  exports.findOne = (req, res) => {
    Driver.findById(req.params.id, (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found Tutorial with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Error retrieving Tutorial with id " + req.params.id
          });
        }
      } else res.send(data);
    });
  };

  exports.update=(req, res) =>{
    if(!req.body){
      res.status(400).send({
        message :"Content can not be empty "
      });
    }
    console.log(req.body);

    Driver.updateById(
      req.params.id, new Driver(req.body), (err, data) =>{
        if (err){
          if(err.kind==="not_found"){
            res.status(400).send({
              message : `Not found driver with id ${req.params.id }.`
            });
          } else {
            res.status(500).send({
              message : "Error updating the Driver with id " + req.params.id
            });
          }

          }else res.send(data);
        }
      );
  };
  exports.delete = (req, res) => {
  Driver.remove(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Tutorial with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Tutorial with id " + req.params.id
        });
      }
    } else res.send({ message: `Driver was deleted successfully!` });
  });
};
