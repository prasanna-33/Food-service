const Customer = require("../models/customer.js");
const emailValidator  = require("email-validator");

function check({ customer }) {
  try {
    const error = {};
    let length = customer.name ? customer.name.length : 0;

    if (length === 0) {
      error.code = 400;
      error.message ="Name is Required";
      return error;
    }
    // email validation
    length = customer.email ? customer.email.length : 0; 
    if(length===0){
      error.code = 400;
      error.message = "Email is Required";
      return error;
    }
    if(!emailValidator.validate(customer.email)){
      error.code =400;
      error.message = "Email not-valid";
      return error;
    }
   
    //password validation
    length = customer.password ? customer.password.length :0;
    if(length===0|| length<8){
      error.code = 400;
      error.message = "Password must contain min 8 characters";
      return error;
    }

    return error;
  } catch (e) {
    throw new Error(e.message);
  }
};
// Create and Save a new customer
exports.create = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  const error = check({ customer:req.body });
    if(error.code==400){
      res.send([error.message]);
    }

  // Create a customer
  const customer = new Customer({
    name: req.body.name,
    email: req.body.email,
    username: req.body.username,
    password: req.body.password,
    lat: req.body.lat,
    lon: req.body.lon,
    contact: req.body.contact,
  });


  // Save customer in the database
  Customer.create(customer, (err, data) => {
    
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the customer."
      });
        else res.send(data);

  });
};

// Retrieve all Customer from the database (with condition).    
exports.findAll = (req, res) => {
  const name = req.query.name;
  
  Customer.getAll(name, (err, data) => {
    if (err)
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving customer."
      });
    else res.send(data);
  });
};
//Retrieve one Customer by id
exports.findOne = (req, res) => {
  Customer.findByMatch(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found customer with  ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving customer with " + req.params.id
        });
      }
    } else res.send(data);
  });
};
exports.update = (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty "
    });
  }
  console.log(req.body);

  Customer.updateById(
    req.params.id, new Customer(req.body), (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(400).send({
            message: `Not found customer with id ${req.params.id}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating the Customer with id " + req.params.id
          });
        }

      } else res.send(data);
    }
  );
};
exports.delete = (req, res) => {
  Customer.remove(req.params.id, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Customer with id ${req.params.id}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete Customer with id " + req.params.id
        });
      }
    } else res.send({ message: `Customer was deleted successfully!` });
  });
};
