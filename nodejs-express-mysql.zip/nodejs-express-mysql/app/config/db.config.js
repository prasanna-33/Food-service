module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "Password",
    DB: "testdb"
  };